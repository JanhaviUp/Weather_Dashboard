const APIKey = "a0aca8a89948154a4182dcecc780b513";
let searchCity = $("#search-city");
let searchButton = $("#search-button");
let clearButton = $("#clear-history");
let currentCity = $("#current-city");
let currentTemperature = $("#temperature");
let currentHumidity = $("#humidity");
let currentWindSpeed = $("#wind-speed");
let currentUvIndex = $("#uv-index");
let cityHistory = JSON.parse(localStorage.getItem("cityname")) || [];

function getWeather(city) {
    let queryURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${APIKey}`;
    
    $.ajax({ url: queryURL, method: "GET" }).then(response => {
        let weatherIcon = response.weather[0].icon;
        let iconURL = `https://openweathermap.org/img/wn/${weatherIcon}@2x.png`;
        let date = new Date(response.dt * 1000).toLocaleDateString();
        
        currentCity.html(`${response.name} (${date}) <img src="${iconURL}">`);
        currentTemperature.html(`${((response.main.temp - 273.15) * 1.8 + 32).toFixed(2)}°F`);
        currentHumidity.html(`${response.main.humidity}%`);
        currentWindSpeed.html(`${(response.wind.speed * 2.237).toFixed(1)} MPH`);

        getUVIndex(response.coord.lon, response.coord.lat);
        getForecast(response.id);
        saveSearch(city);
    });
}

function getUVIndex(lon, lat) {
    let uvURL = `https://api.openweathermap.org/data/2.5/uvi?appid=${APIKey}&lat=${lat}&lon=${lon}`;
    
    $.ajax({ url: uvURL, method: "GET" }).then(response => {
        currentUvIndex.html(response.value);
    });
}

function getForecast(cityId) {
    let forecastURL = `https://api.openweathermap.org/data/2.5/forecast?id=${cityId}&appid=${APIKey}`;
    
    $.ajax({ url: forecastURL, method: "GET" }).then(response => {
        for (let i = 0; i < 5; i++) {
            let index = (i + 1) * 8 - 1;
            let date = new Date(response.list[index].dt * 1000).toLocaleDateString();
            let icon = response.list[index].weather[0].icon;
            let tempF = (((response.list[index].main.temp - 273.15) * 1.8) + 32).toFixed(2);
            let humidity = response.list[index].main.humidity;
            
            $(`#fDate${i}`).html(date);
            $(`#fImg${i}`).html(`<img src="https://openweathermap.org/img/wn/${icon}.png">`);
            $(`#fTemp${i}`).html(`${tempF}°F`);
            $(`#fHumidity${i}`).html(`${humidity}%`);
        }
    });
}

function saveSearch(city) {
    if (!cityHistory.includes(city.toUpperCase())) {
        cityHistory.push(city.toUpperCase());
        localStorage.setItem("cityname", JSON.stringify(cityHistory));
        updateSearchHistory();
    }
}

function updateSearchHistory() {
    $(".list-group").empty();
    cityHistory.forEach(city => {
        $(".list-group").append(`<li class="list-group-item">${city}</li>`);
    });
}

function handleSearch(event) {
    event.preventDefault();
    let city = searchCity.val().trim();
    if (city) getWeather(city);
}

function handleHistoryClick(event) {
    if (event.target.matches("li")) {
        getWeather(event.target.textContent.trim());
    }
}

function loadLastCity() {
    if (cityHistory.length > 0) getWeather(cityHistory[cityHistory.length - 1]);
    updateSearchHistory();
}

function clearHistory() {
    cityHistory = [];
    localStorage.removeItem("cityname");
    updateSearchHistory();
}

// Event Listeners
searchButton.on("click", handleSearch);
$(document).on("click", ".list-group-item", handleHistoryClick);
$(window).on("load", loadLastCity);
clearButton.on("click", clearHistory);
